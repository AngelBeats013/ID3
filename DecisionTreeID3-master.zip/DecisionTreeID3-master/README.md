(1)set	four arguments	from	the	command	line or PyCharm edit configuration -complete	path	of	the	training	dataset,	
complete	path	of	the	validation	dataset,	complete	path of	the	test	dataset,	and	the	pruning	factor.
(2)run main.py
